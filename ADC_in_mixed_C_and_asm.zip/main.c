/********************************************************************************
* main.c: Implementering av ett system inneh�llande PWM-generering f�r
*         styrning av en lysdiod ansluten till pin 8 (PORTB0) via avl�sning
*         av analoga insignaler fr�n en potentiometer ansluten till analog
*         pin A0 (PORTC0). En tryckknapp ansluten till pin 13 (PORTB5)
*         anv�nds f�r att toggla PWM-generering vid nedtryckning.
********************************************************************************/
#include "misc.h"

/********************************************************************************
* Definition av globala variabler:
********************************************************************************/
bool pwm_enabled = false;

/********************************************************************************
* ISR: Avbrottsrutin f�r PCI-avbrott p� I/O-port B, vilket �ger rum vid
*      nedtryckning eller uppsl�ppning av tryckknappen BUTTON1.
*      Vid nedtryckning togglas aktivering av PWM-generering.
********************************************************************************/
ISR (PCINT0_vect)
{
   pwm_check();
   return;
}

/********************************************************************************
* main: Initierar systemet. Lysdioden styrs sedan kontinuerligt med PWM
*       via avl�sning av potentiometern n�r PWM-generering �r aktiverat.
*       F�r PWM-generering anv�nds en periodtid p� 1000 us.
********************************************************************************/
int main(void)
{
   setup();

   while (1)
   {
      pwm_run(POT1, LED1, &PORTB, pwm_enabled, 1000);
   }

   return 0;
}