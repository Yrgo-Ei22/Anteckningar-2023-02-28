/********************************************************************************
* misc.h: Inneh�ller definitioner och deklarationer f�r implementering av
*         det inbyggda systemet.
********************************************************************************/
#ifndef MISC_H_
#define MISC_H_

/********************************************************************************
* Klockfrekvens (beh�vs f�r f�rdr�jningsrutiner):
********************************************************************************/
#define F_CPU 16000000UL /* 16 MHz. */

/********************************************************************************
* Inkluderingsdirektiv:
********************************************************************************/
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdbool.h>

/********************************************************************************
* Konstanter f�r in- och utenheter:
********************************************************************************/
#define LED1    PORTB0
#define BUTTON1 PORTB5
#define POT1    PORTC0

/********************************************************************************
* Deklaration av globala variabler:
********************************************************************************/
extern bool pwm_enabled; /* Indikerar ifall PWM-generering �r aktiverat. */

/********************************************************************************
* setup: Initierar mikrodatorns I/O-portar samt AD-omvandlare. Avbrott aktiveras
*        p� tryckknappens pin f�r att toggla av PWM-generering vid nedtryckning.
********************************************************************************/
void setup(void);

/********************************************************************************
* set: Ettst�ller bit i angivet register utan att p�verka �vriga bitar.
*
*      - reg: Registret som ska skrivas till.
*      - bit: Biten som ska ettst�llas.
********************************************************************************/
static inline void set(volatile uint8_t* reg, 
                       const uint8_t bit)
{
   *reg |= (1 << bit);
   return;
}

/********************************************************************************
* clr: Nollst�ller bit i angivet register utan att p�verka �vriga bitar.
*
*      - reg: Registret som ska skrivas till.
*      - bit: Biten som ska nollst�llas.
********************************************************************************/
static inline void clr(volatile uint8_t* reg,
                       const uint8_t bit)
{
   *reg &= ~(1 << bit);
   return;
}

/********************************************************************************
* read: L�ser av angiven pin och returnerar ifall denna �r h�g eller l�g
*       genom att returnera true (h�g) eller false (l�g).
*
*       - reg: Registret som ska l�sas av.
*       - bit: Den bit som ska kontrolleras.
********************************************************************************/
static inline bool read(const volatile uint8_t* reg,
                        const uint8_t bit)
{
   return (bool)(*reg & (1 << bit));
}

/********************************************************************************
* delay_us: Genererar f�rdr�jning m�tt i us.
*
*           - delay_time_us: F�rdr�jningstiden i us.
********************************************************************************/
static inline void delay_us(const uint16_t delay_time_us)
{
   for (uint16_t i = 0; i < delay_time_us; ++i)
   {
      _delay_us(1);
   }
   return;
}

/********************************************************************************
* adc_read: L�ser av insignalen p� angiven analog pin och returnerar motsvarande
*           digitala v�rde mellan 0 - 1023.
*
*           1. Vi v�ljer att anv�nda intern matningssp�nning p� 5 V. Vi v�ljer
*              ocks� vilken analog pin som ska kopplas till AD-omvandlaren.
*
*           2. Vi aktiverar AD-omvandlaren (ADEN = ADC Enable). Sedan startar
*              vi en ny AD-omvandling (ADSC = ADC Start Conversion). Vi anv�nder
*              l�gsta m�jliga frekvens (16M / 128 = 125 kHz) f�r att
*              AD-omvandlaren ska kunna g�ra s� ackurat omvandling som m�jligt,
*              allts� b�sta m�jliga resultat (ADPS[2:0] s�tter denna frekvens).
*
*           3. Vi v�ntar in att AD-omvandlingen blir f�rdig. Detta indikeras
*              via biten ADIF (ADC Interrupt Flag), som d� blir ettst�lld.
*              D�rmed v�ntar vi via en loop tills ADIF blir ettst�lld.
*              Vi v�ntar via en while-sats, som k�r s� l�nge ADIF �r lika med 0.
*              Semikolonet betyder "g�r ingenting" varje varv i while-satsen.
*              Vi hade kunnat anv�nda m�svingar.
*
*           4. Vi �terst�ller ADIF inf�r n�sta omvandling genom att skriva
*              en etta till denna. ADIF nollst�lls d� av h�rdvaran och kommer
*              kunna anv�ndas vid n�sta AD-omvandling.
*
*           5. Resultatet ligger nu i register ADC. Egentligen �r det tv�
*              8-bitars register ADCH och ADCL (ADC High och ADC Low), men
*              detta beh�ver ni bara t�nka p� i assembler, h�r f�r ni alla
*              bitar genom att skriva ADC. Vi returnerar d�rmed inneh�llet
*              fr�n register ADC, vilket �r ett osignerat heltal mellan
*              0 - 1023.
*
*           - pin: Den analoga pin som ska l�sas av.
********************************************************************************/
uint16_t adc_read(const uint8_t pin);

/********************************************************************************
* pwm_check: Om BUTTON1 trycks ned togglas aktivering av PWM.
********************************************************************************/
void pwm_check(void);

/********************************************************************************
* adc_get_pwm_values: L�ser av angiven analog pin och ber�knar sedan on- och
*                     off-tid f�r PWM-generering via angiven periodtid.
*                     Ber�knade v�rden sparas p� angivna adresser och indikerar
*                     tiden som lysdioden ska vara t�nd respektive sl�ckt.
*
*                     1. Vi ber�knar duty cycle, (hur stor andel av periodtiden
*                        som lysdioden ska vara t�nd) som ett tal mellan 0 - 1
*                        genom att dividera avl�st v�rde fr�n potentiometern med
*                        h�gsta m�jliga v�rde 1023. Vi ber�knar d� hur mycket av
*                        max som potentiometern har vridits mellan 0 - 100 %,
*                        fast h�r i st�llet som ett tal mellan 0 - 1.
*
*                     2. Vi ber�knar on-tiden, allts� tiden som lysdioden ska
*                        vara t�nd under aktuell PWM-period, som periodtiden
*                        multiplicerat med ber�knad duty cycle. Som exempel,
*                        f�r en duty cycle p� 60 % ska on-tiden s�ttas till
*                        60 % av periodtiden, allts� periodtiden * 0.6.
*
*                     3. Vi ber�knar off-tiden, allts� tiden lysdioden ska vara
*                        sl�ckt under aktuell PWM-period, genom att ber�kna
*                        resterande periodtid, dvs. periodtiden minus on-tiden.
*
*                     - pin        : Den analoga pin A0 - A5 som ska l�sas av.
*                     - period_us  : Periodtid f�r PWM i mikrosekunder.
*                     - on_time_us : Referens till variabel d�r on-tiden ska
*                                    lagras i mikrosekunder.
*                     - off_time_us: Referens till variabel d�r off-tiden ska
*                                    lagras i mikrosekunder.
********************************************************************************/
static inline void adc_get_pwm_values(const uint8_t pin,
                                      const uint16_t period_us,
                                      uint16_t* on_time_us,
                                      uint16_t* off_time_us)
{
   const double duty_cycle = adc_read(pin) / 1023.0;
   *on_time_us = (uint16_t)(period_us * duty_cycle + 0.5);
   *off_time_us = period_us - *on_time_us;
   return;
}

/********************************************************************************
* pwm_run: Styr specificerad utenhet med en PWM-signal avl�st fr�n specifierad
*          potentiometer ifall pwm-generering �r aktiverat.
*
*          - pot_pin   : Potentiometerns pin-nummer.
*          - output_pin: utenhetens pin-nummer.
*          - output_reg: Referens till utenheterns portregister.
*          - enabled   : Indikerar ifall PWM-generering �r aktiverat.
*          - period_us : Periodtid f�r PWM-generering i us.
********************************************************************************/
static inline void pwm_run(const uint8_t pot_pin,
                           const uint8_t output_pin,
                           volatile uint8_t* output_reg,
                           const bool enabled,
                           const uint16_t period_us)
{
   if (enabled)
   {
      uint16_t pwm_on_us, pwm_off_us;
      adc_get_pwm_values(pot_pin, period_us, &pwm_on_us, &pwm_off_us);

      set(output_reg, output_pin);
      delay_us(pwm_on_us);
      clr(output_reg, output_pin);
      delay_us(pwm_off_us);
   }
   return;
}

#endif /* MISC_H_ */